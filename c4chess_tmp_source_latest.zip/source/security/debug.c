#include "debug.h"

// implement a printf type func
/*
void DEBUG_Print(char *data) {

    return;
}
*/
