#ifndef SEC_H
#define SEC_H

// manage all errors here when ready

#endif
