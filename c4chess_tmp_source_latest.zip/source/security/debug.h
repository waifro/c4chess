#ifndef DEBUG_H
#define DEBUG_H

// implement a printf type func
//void DEBUG_Print(char *data);

#endif
