#include "send.h"

/*
int SEND_SendData(char *buffer) {

    return;
}
*/
