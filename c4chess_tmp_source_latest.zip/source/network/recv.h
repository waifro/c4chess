#ifndef RECV_H
#define RECV_H

//int RECV_RecieveData(char *buffer);

#endif
