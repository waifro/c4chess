#include "recv.h"

/*
int RECV_RecieveData(char *buffer) {


    return;
}
*/
