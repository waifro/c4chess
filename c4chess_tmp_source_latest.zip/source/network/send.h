#ifndef SEND_H
#define SEND_H

//int SEND_SendData(char *buffer);

#endif
