/* Private Project Four Me */

#ifndef _PP4M_IO_H
#define _PP4M_IO_H

#include <stdbool.h>

bool pp4m_IO_CheckFile(char *filename);
void pp4m_IO_Feedback(char *filename, const char *text);

#endif // _PP4M_IO_H

/* 2022 @waifro */
